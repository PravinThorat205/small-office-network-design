# Small-Office Subnet & Service Design Note

**Project:** Small Office Network Design  
**Type:** Capstone project write-up  
**Status:** Proposed design and test plan (not a deployed network)

## Abstract

This project proposes a secure and manageable network for a small office. It uses IPv4 subnetting and VLAN segmentation to separate staff devices, servers, guest wireless clients, network management, and printers/IoT devices. The design documents gateway addresses, example DHCP scopes, DNS service requirements, outbound NAT, and high-level firewall rules. A verification checklist is included to support implementation and testing. The design is intended as a starting point and must be adapted to the selected equipment and actual business requirements before deployment.

## 1. Requirements

The office needs reliable connectivity for employee computers and Wi-Fi, shared services, guest internet access, printers, and network administration. Guest devices should not access internal resources, and management interfaces should be reachable only from an authorized management network.

## 2. Network topology

The ISP connection terminates at a firewall/router. A VLAN-aware managed switch connects to the firewall using an 802.1Q trunk. Staff and guest wireless networks are mapped to separate VLANs through access points. Servers, printers, and management interfaces are placed in their own VLANs where supported.

See `diagrams/network-topology.txt` for the text topology.

## 3. IPv4 subnetting and VLAN plan

The proposed private address block is `192.168.10.0/23`, divided as follows:

| VLAN | Purpose | CIDR | Gateway |
|---:|---|---|---|
| 10 | Staff | `192.168.10.0/26` | `192.168.10.1` |
| 20 | Servers | `192.168.10.64/27` | `192.168.10.65` |
| 30 | Guest Wi-Fi | `192.168.10.96/26` | `192.168.10.97` |
| 40 | Network management | `192.168.10.160/28` | `192.168.10.161` |
| 50 | Printers/IoT | `192.168.10.176/27` | `192.168.10.177` |

The selected subnet sizes provide different capacities for different device groups. The network administrator should reserve network and broadcast addresses, keep gateway addresses consistent, and verify that no overlapping subnets exist elsewhere in the organization.

## 4. Services

**DHCP:** Provide each client VLAN with a separate scope and the correct gateway, subnet mask, and DNS settings. Use reservations for devices requiring stable addresses.

**DNS:** Use an approved internal resolver for internal names and external resolution. Do not expose internal records to guest clients.

**NAT:** Configure source NAT/PAT on the perimeter firewall for approved outbound connections. Block unsolicited inbound connections unless a documented business requirement exists.

**Firewall:** Apply a default-deny policy between VLANs. Permit only required application flows. Guest clients should have internet access but no access to internal subnets. Administration should originate from the management VLAN.

## 5. Security controls

Use unique administrator credentials and MFA where available. Secure Wi-Fi with WPA2-AES or WPA3. Keep network firmware updated, disable unused switch ports, restrict management interfaces, back up configurations, and review security logs. Remote administration should use a secured VPN rather than direct exposure of management ports.

## 6. Test plan

The implementation should be verified by checking that:
1. Staff and guest devices receive addresses from the correct DHCP scopes.
2. Clients receive the correct gateway and DNS settings.
3. Approved DNS lookups succeed.
4. Staff can access only authorized internal services.
5. Guest devices cannot reach internal VLANs.
6. Approved clients can access the internet through NAT.
7. Unsolicited inbound connections are blocked.
8. Network management interfaces are accessible only from authorized devices.

Record actual results before declaring any test successful. This document does not claim that tests have already been run.

## 7. Conclusion

The proposed design uses subnetting, VLANs, standard network services, and least-privilege firewall rules to improve separation and manageability in a small office. It provides a documented basis for a lab demonstration or a later production implementation.

## References for further study

- RFC 1918, *Address Allocation for Private Internets*.
- RFC 2131, *Dynamic Host Configuration Protocol*.
- RFC 1034 and RFC 1035, *Domain Names—Concepts and Facilities* / *Implementation and Specification*.
- IEEE 802.1Q, *Bridges and Bridged Networks* (VLAN tagging).
