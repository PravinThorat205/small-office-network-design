# Small Office Network Design

A practical small-office subnet and service design project covering IPv4 subnetting, VLAN segmentation, DHCP, DNS, NAT, firewall rules, and network security.

## 1. Project overview

This design is for a small office with around 25–40 employees. It separates staff devices, guest Wi-Fi, servers, and network management into separate VLANs to improve security and simplify troubleshooting.

**Design goals**
- Separate office traffic into logical VLANs.
- Use private IPv4 addressing and a clear subnet plan.
- Provide DHCP for client devices and DNS for name resolution.
- Allow controlled internet access through NAT.
- Restrict traffic between VLANs using firewall rules.
- Document a repeatable validation checklist.

## 2. Proposed topology

```text
                         Internet
                            |
                      [ISP modem/ONT]
                            |
                    [Firewall / Router]
                       802.1Q trunk
                            |
                     [Managed Switch]
              _____________|____________________
             |             |          |         |
          VLAN 10       VLAN 20    VLAN 30   VLAN 40
           Staff        Servers     Guest     Network
          PCs/Wi-Fi    DNS/File    Wi-Fi     Management
```

A separate VLAN 50 is reserved for printers and shared office devices. The switch uplink to the firewall carries tagged VLANs. Wireless access points map staff and guest SSIDs to their respective VLANs.

## 3. VLAN and IPv4 addressing plan

Office private address block: `192.168.10.0/23`

| VLAN | Name | Subnet | Gateway | Example allocation |
|---:|---|---|---|---|
| 10 | Staff | `192.168.10.0/26` | `192.168.10.1` | DHCP `192.168.10.10–192.168.10.62` |
| 20 | Servers | `192.168.10.64/27` | `192.168.10.65` | Static addresses `192.168.10.66–94` |
| 30 | Guest Wi-Fi | `192.168.10.96/26` | `192.168.10.97` | DHCP `192.168.10.100–158` |
| 40 | Network management | `192.168.10.160/28` | `192.168.10.161` | Static/reserved `192.168.10.162–174` |
| 50 | Printers/IoT | `192.168.10.176/27` | `192.168.10.177` | Reservations `192.168.10.178–206` |

**Subnetting note:** Each subnet has a network address and broadcast address that cannot be assigned to hosts. The gateway is reserved as the first usable address. Confirm the DHCP ranges in the table against the actual DHCP server configuration before deployment.

## 4. Core network services

### DHCP
- Provide automatic addressing for staff and guest clients.
- Configure the correct subnet mask, default gateway, and DNS server per VLAN.
- Use reservations for printers and other devices that need stable addresses.
- Do not run an unrestricted DHCP service on the guest network.

### DNS
- Use an internal DNS resolver for approved office hostnames and external lookups.
- Provide DHCP clients with the approved DNS resolver address.
- Restrict server administration interfaces to the management VLAN.
- Avoid exposing internal DNS records to guest devices.

### NAT and internet access
- Use source NAT/PAT on the firewall for approved internal VLANs.
- Permit outbound internet access according to the office's policy.
- Block unsolicited inbound connections from the internet by default.
- If remote access is needed, use a properly secured VPN rather than exposing admin ports.

## 5. Firewall policy (high-level)

| Source | Destination | Policy | Reason |
|---|---|---|---|
| Staff VLAN | Approved servers | Allow required ports only | Work applications and file services |
| Staff VLAN | Internet | Allow as required | Business use |
| Guest VLAN | Internal VLANs | Deny | Isolate visitors |
| Guest VLAN | Internet | Allow web/DNS as required | Guest connectivity |
| Management VLAN | Network devices | Allow admin protocols | Controlled administration |
| User VLANs | Management VLAN | Deny by default | Protect device management |
| Internet | Internal networks | Deny unsolicited inbound | Reduce exposure |
| Printers/IoT VLAN | Staff/servers | Allow only required flows | Limit lateral movement |

Use a default-deny approach between VLANs, then add narrowly scoped rules for documented business requirements. The exact ports depend on the services actually deployed.

## 6. Example configuration notes

The files in `configs/` provide illustrative examples. They are not a complete device configuration and must be adapted to the selected firewall, switch, DHCP server, and DNS platform.

- `configs/dhcp-example.txt`: example DHCP scopes.
- `configs/firewall-policy-example.txt`: readable policy outline.
- `configs/switch-vlan-example.txt`: generic VLAN and trunk planning notes.

## 7. Security measures

- Change default passwords and use unique administrator accounts.
- Enable MFA for cloud/admin portals where available.
- Use WPA2-AES or WPA3 for Wi-Fi; use a separate guest SSID.
- Keep firewall, switch, access point, and server firmware updated.
- Back up configurations and store backups with restricted access.
- Disable unused switch ports and unused services.
- Use endpoint protection and disk encryption on supported devices.
- Log firewall denials and administrative changes; review logs periodically.
- Keep network equipment in a locked or access-controlled location.
- Document an owner and review date for each firewall rule.

## 8. Testing and verification checklist

Complete these checks in a lab or during an approved maintenance window.

- [ ] A staff client receives an address from the staff DHCP scope.
- [ ] A guest client receives an address from the guest scope.
- [ ] Each client receives the correct gateway and DNS server.
- [ ] Clients can resolve approved DNS names.
- [ ] Staff devices can reach only the approved internal services.
- [ ] Guest devices cannot reach staff, server, management, or printer subnets.
- [ ] Approved VLANs can reach the internet through NAT.
- [ ] Unsolicited inbound internet traffic is blocked.
- [ ] Only management devices can reach network-device admin interfaces.
- [ ] Configuration backups are saved and can be located by the administrator.

Record the date, test device/VLAN, expected result, actual result, and pass/fail status when performing the tests. Do not mark a test as passed until it has actually been run.

## 9. Assumptions and limitations

This is a proposed design, not evidence of a deployed network. Hardware selection, exact port requirements, redundancy, ISP details, regulatory requirements, and the final firewall syntax depend on the real office environment. Validate the subnet plan and rules before production use.

## 10. Conclusion

VLAN segmentation, a documented IPv4 plan, managed DHCP/DNS services, NAT, and restrictive firewall rules provide a clear baseline for a small-office network. The accompanying checklists make the design easier to implement, test, and maintain.

## Suggested repository contents

```text
small-office-network-design/
├── README.md
├── report.md
├── diagrams/
│   └── network-topology.txt
└── configs/
    ├── dhcp-example.txt
    ├── firewall-policy-example.txt
    └── switch-vlan-example.txt
```
